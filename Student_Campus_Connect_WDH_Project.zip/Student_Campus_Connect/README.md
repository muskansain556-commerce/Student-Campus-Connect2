# Student Campus Connect — WDH Innovative Website

**Student:** Muskan Sain  
**Course:** Web Designing using HTML (WDH)  
**Programme:** BCA Semester 1  
**Project option:** Student Campus Connect Website

## Run the website
1. Extract the ZIP file.
2. Open the `Student_Campus_Connect` folder.
3. Open `index.html` in Chrome, Edge or Firefox.
4. Use the navigation menu to visit all five pages.

For the best experience, keep all files and the `assets` folder together. An internet connection is needed for the online photos, Google Fonts and sample embedded video.

## Pages
- `index.html` — Home and quick links
- `about.html` — Purpose, objectives and target audience
- `academics.html` — BCA information, sample timetable and learning links
- `campus-life.html` — Interactive interests, sample events and video
- `contact.html` — Feedback form demonstration

## Features and concepts
- HTML5 semantic page structure, headings, paragraphs and lists
- Shared responsive CSS navigation and mobile menu
- Image content, hyperlinks and external learning resources
- HTML table for a sample weekly timetable
- Required-field and email validation in the feedback form
- Interactive interest cards using JavaScript
- Embedded sample video
- Responsive layouts for mobile, tablet and desktop
- Sitemap and testing checklist included

## Important notes
- Timetable and event information is sample/demo content, not official college information.
- The feedback form is a front-end demonstration. It validates the form but does not send, save or email submissions.
- Photos, Google Fonts and the embedded video are online resources and need internet access.
- Replace sample details with verified information before presenting it as an official college website.

## Publish using GitHub Pages
1. Sign in at https://github.com/.
2. Create a new **Public** repository, for example `student-campus-connect`.
3. Extract this ZIP and upload the contents of the `Student_Campus_Connect` folder (the HTML, CSS, JS and documentation files). Do not upload only the ZIP.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then press **Save**.
7. Wait for GitHub Pages to publish. Copy the website URL shown in Settings → Pages. It usually looks like `https://YOUR-USERNAME.github.io/student-campus-connect/`.
8. Open that URL in a private/incognito tab or another device and test every page.

## Submit in Google Classroom
1. Open Google Classroom and choose the correct WDH class.
2. Open the assignment set by your teacher.
3. Press **Add or create → Link** and paste your published GitHub Pages website URL.
4. Also attach the ZIP file if your teacher asks for source code. Attach the project report/documentation if required.
5. Check that the link is correct and opens publicly.
6. Press **Turn in** and confirm the submission.

If your teacher asks for a Google Drive link instead, upload the ZIP to Drive, set access as requested by the teacher, and attach that link. Follow the teacher's exact instructions.

## Testing checklist
- [ ] Home page opens
- [ ] All five navigation links work
- [ ] Mobile menu opens and closes
- [ ] Images load when internet is available
- [ ] Academic table is readable on mobile (horizontal scroll if needed)
- [ ] Interest cards show a suggestion when clicked
- [ ] Feedback form blocks empty/invalid required fields
- [ ] Feedback form shows a demo success message
- [ ] Video loads when internet is available
- [ ] GitHub Pages link opens without signing in
