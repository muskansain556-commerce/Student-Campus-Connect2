// Mobile navigation and small interactive demonstrations.
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
if (menuButton && nav) {
  menuButton.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
    menuButton.textContent = isOpen ? '×' : '☰';
  });
}
const interestIdeas = {
  tech: 'Try a mini website, coding puzzle or beginner-friendly tech workshop.',
  art: 'Start a poster challenge, sketch meetup or collaborative design project.',
  sports: 'Find a friendly match, walking group or weekly fitness challenge.',
  culture: 'Help plan a celebration, open-mic session or student talent showcase.'
};
document.querySelectorAll('.club-card').forEach(card => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.club-card').forEach(item => item.classList.remove('selected'));
    card.classList.add('selected');
    const result = document.getElementById('interest-result');
    if (result) result.textContent = interestIdeas[card.dataset.interest] || 'Explore an activity and invite a friend.';
  });
});
const feedbackForm = document.getElementById('feedback-form');
if (feedbackForm) {
  feedbackForm.addEventListener('submit', event => {
    event.preventDefault();
    if (!feedbackForm.reportValidity()) return;
    const status = document.getElementById('form-status');
    status.textContent = 'Thank you! Your demo form passed validation. No information was sent or stored.';
    feedbackForm.reset();
  });
}
