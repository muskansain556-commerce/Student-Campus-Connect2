# AI Usage Documentation

**Tool used:** ChatGPT  
**Purpose:** Planning the Student Campus Connect website, generating starter HTML/CSS/JavaScript, and preparing the project structure and submission checklist.

**Example prompt:** "Create a responsive multi-page Student Campus Connect website for a WDH HTML/CSS assignment, with navigation, images, a timetable, a feedback form, an interactive student resource section and a sitemap."

**Student review and changes required:** Open and test every page, verify all content, replace sample timetable/event details with approved information if needed, check external media, and make any changes required by the teacher. The student should understand and be able to explain the HTML, CSS and JavaScript used.
