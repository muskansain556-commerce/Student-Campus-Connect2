# Website Testing and Validation

| Test | Expected result | Status |
|---|---|---|
| Open index.html | Home page loads | To be tested on your device |
| Main navigation | All five pages open | To be tested |
| Mobile navigation | Menu opens/closes | To be tested |
| Interest cards | Clicking a card shows a suggestion | To be tested |
| Feedback form | Required fields and email are validated | To be tested |
| Feedback form submit | Demo confirmation appears; no data is sent | To be tested |
| Responsive layout | Content adapts to phone/tablet/desktop widths | To be tested |
| External images/video | Load with an internet connection | To be tested |

Record your actual test date, browser and results before final submission. Do not mark tests as passed until you have checked them yourself.
